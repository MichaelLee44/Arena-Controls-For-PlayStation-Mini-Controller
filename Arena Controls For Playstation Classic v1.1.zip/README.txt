-requires the program GlovePIE to work
-to operate, plug in controller, open file with glovepie, press run

Controls [basic version]

Mouse - Dpad
Forward - Triange
Left - Square
Backward - X
Right - Circle
Left Click - L2
Right Click - R2
Cast - L1
Sheath/Draw Weapon - R1
Pause/Exit - Start
Jump Forward - Select
debug mouse speed (do this if your weapon is drawn but your mouse is moving too slow or vice versa) - L2 + R2



Controls [toggle controls Version]

Universal-
Mouse - Dpad
Toggle Mode for Other Buttons - Select
debug mouse speed (do this if your weapon is drawn but your mouse is moving too slow or vice versa) - L2 + R2

Mode 1-
Forward - Triange
Left - Square
Backward - X
Right - Circle
Left Click - L2
Right Click - R2
Cast - L1
Sheath/Draw Weapon - R1
Jump Forward - Start

Mode2-
World Map - Triangle
Rest - Square
Local Map - X
Inventory - Circle
Pilfer - L2
Use Potion/Item - R2
Logbook - L1
Pause/Exit - Start


